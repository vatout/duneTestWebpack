import React, { Component } from 'react';
import ColorPixel from "./colorpixel/ColorPixel"
import logo from './logo.svg';
import './App.css';

function Mockup() {
   var input = {
     mode:{},
     students:[
       {label:"Student 1"},
       {label:"Student 2"},
       {label:"Student 3"},
       {label:"Student 4"},
      ],
   };
   const result = {location:{state:input}};
   return (result);
}

class App extends Component {
  render() {
    return (
      <div className="App">
        <ColorPixel location={Mockup().location}/>
      </div>
    );
  }
}

export default App;
