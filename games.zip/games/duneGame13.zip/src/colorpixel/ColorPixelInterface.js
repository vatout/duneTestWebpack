import React, { Component } from 'react';
import { Grid, Paper } from '@material-ui/core';

function interfaceStyle(left, right) {
    return ({
        zIndex:"-1",
        position:"fixed",
        bottom:"5vh",
        top:"5vh",
        width:"40vh",
        left:left,
        right:right,
    });
};

export default class ColorPixelInterface extends Component {
    constructor(props) {
        super(props);
        this.state = {
            dictionnary:this.props.dictionnary
        };
    }
    updateDictionnary(newone) {
        this.setState({
            dictionnary:newone
        });
    }
    changeColor(id) {
        this.props.changeColor(id);
    }
    renderColorTab() {
        const len = this.state.dictionnary.length;
        const tab = this.state.dictionnary.map((value) => {
            const height = 100 / len + "%";
            var style = {
                position:"relative",
                margin:"auto",
                top:"50%",
                transform:"translate(0,-50%)",
                textShadow:"-1px -1px 1px #111, 2px 2px 1px #363636;color:#262626",
                fontSize: 1000 / len + "%"
            };
            return (
                <Grid item style={{backgroundColor:value.value, height:height}} onClick={() => {this.changeColor(value.id)}}>
                    <div style={style}>
                        {value.id}
                    </div>
                </Grid>
            )
        }, len);
        return (<Grid style={{padding:"5%", height:"100%"}} container direction="column">
            {tab}
        </Grid>);
    }
    render() {
        return (
            <div>
            <Paper style={interfaceStyle("5vh", null)}>
                {this.renderColorTab()}
            </Paper>
            <Paper style={interfaceStyle(null, "5vh")}>
                {this.renderColorTab()}
            </Paper>
            </div>
        );
    }
}