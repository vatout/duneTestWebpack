import React, { Component } from 'react';
import { Grid, Button, Paper } from '@material-ui/core';

const CompteClassePlateStyle = {
    position:"fixed",
    width:"90%",
    left:"5%",
    right:"5%",
    top:"5%",
    height:"50%",
    overflowY:"hidden"
};

const CompteClassePlateContainerStyle = {
    height:"100%",
    width:"100%",
    left:"20%",
    right:"20%",
    top:"2%",
    bottom:"2%",
    paddingTop:"2.5%",
    paddingLeft:"2.5%",
    paddingRight:"2.5%",
}


function testList() {
    return (
        [
            {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, 
            {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, 
            {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, 
            {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, 
            {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, 
            {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, 
            {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, 
            {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, 
            {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, 
            {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, {imgSrc:"https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png"}, 
        ]
    );
}

export default class CompteClassePlate extends Component {
    constructor(props) {
        super(props);
        this.state = {
            list:[
            ],
        };
    }
    updateList(newList) {
        var tmpstate = this.state;
        tmpstate.list = newList;
        this.setState(tmpstate);
    }
    getItemStyle() {
        var length = this.state.list.length;
        const nbColumn = 8;
        var nbLine = 1;
        while (length > nbColumn) {
            nbLine += 1;
            length -= nbColumn;
        }
        const width = 1 / nbColumn * 100;
        const height = 1 / nbLine * 100;
        var result = {
            width:width + "%",
            height:height + "%",
        };
        return (result);
    }
    renderList() { 
        const result = this.state.list.map((value) => {
            return (
                <Grid item style={this.getItemStyle()}>
                    <div style={{height:"100%", width:"100%", position:"relative"}}>
                        <div style={{position:"absolute", margin:"0", top:"50%", transform:"translate(0,-50%)"}}>
                            <img src={value.imgSrc} width="100%" height="auto"
                            />
                        </div>
                    </div>
                </Grid>
            );
        });
        return (result);
    }
    render() {
        return (
            <Paper style={CompteClassePlateStyle}>
                <Grid
                    style={CompteClassePlateContainerStyle}
                    container
                    spacing={16}
                >
                    {this.renderList()}
                </Grid>
            </Paper>
        );
    }
}