import React, { Component } from 'react';
import { Grid, Button } from '@material-ui/core';

import GroupGrid from './GroupGrid'
import CompteClasseInterface from './CompteClasseInterface';
import ChoiceRow from './ChoiceRow';
import PlateCase from './PlateCase';
import GoodAnswerDialog from './GoodAnswerDialog';

const MAX_ELEMS = 24;
const MAX_CHOICES = 16;

//TODO
// mettre en avant le tour (flèche, clignote, etcs)
// ajouter des listes
// 

function rangeRandom(min, max) {
    var result = Math.floor(Math.random() * (max) + min);
    return (result);
}

function shuffle(array) {
    var currentIndex = array.length, temporaryValue, randomIndex;

    // While there remain elements to shuffle...
    while (0 !== currentIndex) {

        // Pick a remaining element...
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;

        // And swap it with the current element.
        temporaryValue = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temporaryValue;
    }
    return array;
}

const groups = {
    lists: [
        {
            name: "fruits",
            list: [
                { tags: ["rouge", "une cerise"], imgSrc: "https://cdn.aroma-host.net/cms/sites/default/files/fiche_technique/fragrances_cosmetiques/Visuel_cerise-exquise.png" },
                { tags: ["jaune", "une banane"], imgSrc: "http://www.icone-png.com/png/13/13081.png" },
                { tags: ["jaune", "un ananas"], imgSrc: "http://lesillonfruitsec.fr/wp-content/uploads/2014/09/Ananas.png"},
                { tags: ["vert", "une grappe de raisins"], imgSrc: "http://www.letribunaldunet.fr/wp-content/uploads/2012/07/grappe_de_raisins_verts_3.png"},
                { tags: ["rouge", "une fraise"], imgSrc: "http://lepassetempsderose.l.e.pic.centerblog.net/o/2bbfda0d.png"},
            ]
        },
        {
            name: "jouets",
            list: [
                { tags: ["un cube",], imgSrc: "https://pngimage.net/wp-content/uploads/2018/06/jouet-png.png" },
                { tags: ["un xylophone", "un instrument"], imgSrc: "http://bilette70.b.i.pic.centerblog.net/0_8eba4_a9ab451d_L.png" },
                { tags: ["un cheval", "équipés de roues"], imgSrc: "http://www.unirpuntos.com/data/images/un-caballo-de-palo-con-ruedas,-caballo-de-juguete_56e853ddf079a-thumb.jpg"},
                { tags: ["une voiture", "équipés de roues"], imgSrc: "https://selency.imgix.net/e1c9e702-72e5-4020-b422-afba9a7c18ac/rayer-la-voiture-jouet-en-bois-construit-vers-les-annees-1930_original.png?bg=0FFF&fit=fill&auto=format%2Ccompress&w=600&h=600&meta_format=product_og"}
            ]
        },
        {
            name: "air,terre,mer",
            list: [
                { tags: ["un avion", "dans les airs"], imgSrc: "https://i0.wp.com/professionals.aero/wp-content/uploads/2016/10/avion.png?ssl=1"},
                { tags: ["un animal", "un canard", "dans l'eau", "sur terre", "dans les airs"], imgSrc: "http://www.stickpng.com/assets/images/5a0193067ca233f48ba6272c.png"},
                { tags: ["un animal", "un poisson", "dans l'eau"], imgSrc: "http://www.nayatidreams.fr/wp-content/uploads/2018/08/animalerie-toutou-poisson-rouge-1024x768.png"},
                { tags: ["un animal", "un escargot", "sur terre"], imgSrc: "https://leblogueduginkgodor.files.wordpress.com/2016/03/gros-gris.png?w=640"},
                { tags: ["une voiture", "sur terre"], imgSrc:"https://media.playmobil.com/i/playmobil/6572_product_detail?locale=fr-BE,fr,*&$pdp_product_main_xl$&strip=true"},
                { tags: ["un bateau", "dans l'eau"], imgSrc:"https://www.besset-bateaux.fr/userfiles//6970/besset-bateau-bateau2.png"},
                { tags: ["un animal", "un manchot", "dans l'eau", "sur terre"], imgSrc:"http://www.stickpng.com/assets/images/5a0591809cf05203c4b60418.png"}
            ]
        }
    ],
    getList: function (nb_elem) {
        var random_index = rangeRandom(0, (this.lists.length));
        const list = this.lists[random_index].list;
        var result = [];
        for (var i = 0; i < nb_elem; ++i) {
            random_index = rangeRandom(0, (list.length));
            result.push(list[random_index]);
        }
        return (result);
    }
};

/*
Graphically : Grid displaying the state of the game.
Also check if the game is done and generate score at the end
props needed are :
 - studentList (Array)
 - dictionnary (object containing colors both in hex and string format. ex: red -> 0xff0000)
 - endOfGame (callback to use at the end of the game to return scores and redirect to menu)
*/
export default class CompteClassePlate extends Component {
    constructor(props) {
        super(props);
        const nb_elem = 8;
        const nb_choices = 4;
        this.difficulty = 0;
        this.allGood = 1;
        this.scores = [
            {id:0, value:0},
            {id:1, value:0},
            {id:2, value:0},
            {id:3, value:0},
        ];
        this.ColorDictionnary = this.props.dictionnary;
        this.CompteClassePlateStyle = {
            margin: "auto",
            display: "none",
            position: "fixed",
            width: "70%",
            marginLeft: "15%",
            padding: "8px",
            textAlign: "center",
            display: "table-cell",
            verticalAlign: "middle",
            overflowY:"hidden"
        };
        this.CompteClassePlateLineStyle = {
            margin: "auto",
            position: "static",
            width: "fit-content",
            verticalAlign: "middle",
        };
        const list = groups.getList(nb_elem);
        const tag = this.pickTag(list);
        const choices = this.pickchoicesFromNewList(list, tag, nb_choices)
        this.state = {
            roundLeft:20,
            currentColor: null,
            turn: 0,
            list: list,
            choices: choices,
            tag: tag,
            nb_elem: nb_elem,
            nb_choices: nb_choices,
        }
        this.interfaceRef = React.createRef();
        this.choiceRef = React.createRef();
        this.groupRef = React.createRef();
        this.answerRef = React.createRef();
    }
    endGame() {
        var score = {};
        const buttons = this.interfaceRef.current.buttonsData;
        score.studentsScores = this.scores.map((value, index) => {
            const name = buttons[index].student;
            return (
                {student:name, score:value.value, medal:[]}
            );
        }, buttons);
        score.globalScore = 0;
        score.studentsScores.forEach((value) => {
            score.globalScore += value.score;   
        }, score.globalScore);
        this.props.endOfGame(score);
    }
    setDifficulty(value) {
        this.difficulty = value;
        var tmpState = this.state;
        tmpState.nb_choices = 4 + (value);
        tmpState.nb_elem = 8 + (value * 2);
        if (tmpState.nb_elem > MAX_ELEMS)
            tmpState.nb_elem = MAX_ELEMS;
        if (tmpState.nb_choices > MAX_CHOICES)
            tmpState.nb_choices = MAX_CHOICES;
        this.setState(tmpState);
    }
    getRealResult() {
        var realResult = 0;
        const tag = this.state.tag;
        this.state.list.forEach((value) => {
            if (value.tags.includes(tag))
                realResult += 1;
        }, tag, realResult);
        return (realResult);
    }
    initNextTurn() {
        if (this.state.turn === 3) {
            this.answerRef.current.showAnswer(this.getRealResult());
            var tmpState = this.state;
            tmpState.turn += 1;
            this.setState(tmpState);
        }
        else if (this.state.turn === 4) {
            this.initNextRound();
        }
        else {
            var tmpState = this.state;
            tmpState.turn += 1;
            this.interfaceRef.current.nextTurn();
        }
    }
    initNextRound() {
        var tmpState = this.state;
        if (tmpState.roundLeft === 0) {
            this.endGame();
            return ;
        }
        tmpState.roundLeft--;
        if (this.difficulty < this.allGood)
            this.setDifficulty(this.difficulty + 1);
        else if (this.allGood === 0 && this.difficulty !== 0)
            this.setDifficulty(this.difficulty - 1);
        this.allGood += 1;
        this.newList();
        tmpState.turn = 0;
        this.interfaceRef.current.setTurn(0);
        this.setState(tmpState);
    }
    newList() {
        var tmpState = this.state;
        tmpState.list = groups.getList(tmpState.nb_elem);
        tmpState.tag = this.pickTag(tmpState.list);
        tmpState.choices = this.pickchoicesFromNewList(tmpState.list, tmpState.tag, tmpState.nb_choices);
        this.setState(tmpState);
    }
    pickTag(list) {
        const elem = list[rangeRandom(0, list.length)];
        return (elem.tags[rangeRandom(0, elem.tags.length)]);
    }
    countTag(list, tag) {
        var result = 0;
        list.forEach(element => {
            if (element.tags.includes(tag))
                result += 1;
        }, result, tag);
        return (result);
    }
    pickchoicesFromNewList(list, tag, nb_elem) {
        const realAnswer = this.countTag(list, tag);
        var result = [realAnswer];
        var fakeAnswer;
        for (var i = 1; i < nb_elem; ++i) {
            fakeAnswer = realAnswer;
            while (result.includes(fakeAnswer))
                fakeAnswer = rangeRandom(0, list.length);
            result.push(fakeAnswer);
        }
        result = shuffle(result);
        return (result);
    }
    playerTurn(player, choice) {
        var realResult = 0;
        const tag = this.state.tag;
        this.state.list.forEach((value) => {
            if (value.tags.includes(tag))
                realResult += 1;
        }, tag, realResult);
        if (choice === realResult) {
            this.goodChoice(player);
        }
        else
            this.allGood = 0;
    }
    goodChoice(player) {
        var i = 0;
        while (i < this.scores.length) {
            if (i === player) {
                this.scores[i].value += (this.difficulty + 1);
            }
            ++i;
        }
    }
    turn(value) {
        this.playerTurn(this.state.turn, value);
        this.initNextTurn();
    }
    onChoice = (value) => {
        this.turn(value);
    }
    renderChoice() {
        return (<ChoiceRow ref={this.choiceRef} onChoice={this.onChoice} />);
    }
    renderGroup() {
        return (<GroupGrid ref={this.groupRef} />);
    }
    render() {
        var choice = this.renderChoice();
        var group = this.renderGroup();
        if (this.choiceRef.current != null)
            this.choiceRef.current.updateChoices(this.state.choices.map((value) => { return { label: value, value: value } }), this.state.tag);
        if (this.groupRef.current != null)
            this.groupRef.current.updateList(this.state.list);
        return (
            <div style={this.CompteClassePlateStyle} alignContent='center'>
                {group}
                {choice}
                <CompteClasseInterface ref={this.interfaceRef} dictionnary={this.ColorDictionnary} studentList={this.props.studentList} />
                <GoodAnswerDialog ref={this.answerRef} onQuit={() =>{this.initNextTurn();}}/>
            </div>
        );
    }
}